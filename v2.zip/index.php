<?php
    if (!isset($_GET["user"])) $user = 0;
    else $user = $_GET["user"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Strona główna</title>
</head>
<body style="background-image: url(images/bg.webp);background-position: center;background-size: cover;">
    <div class="header center">
        <div class="header_left center"><h1>Moja strona</h1></div>

        <!-- Subpages -->
        <div class="header_middle center">
            <a href="subpages/gotowanie.php<?php echo "?user=" . $user?>">Gotowanie</a>
            <a href="subpages/sport.php<?php echo "?user=" .  $user?>">Sport</a>
            <a href="subpages/informatyka.php<?php echo "?user=" .  $user?>">Informatyka</a>
            <!-- This option is only visible if user is logged in -->
            <?php
                if ($user){
                    echo "<a href='subpages/hackowanie.php" . "?user=" .  $user . "'>Konto</a>";
                }
            ?>
        </div>
        <div class="header_right center"><a href="index.php"><div class="login_button center">zaloguj sie</div></a></div>
    </div>
    <div class="middle center">
        <!-- Logging form -->
        <form method="POST" action="login.php" class="center">
            <?php if (isset($_GET["error"])) echo "<p>Podano niepoprawne dane!</p>";?>
            LOGIN: <input type="text" name="login" required placeholder="Napisz tu swój login"><br/>
            PASSWORD: <input type="password" name="password" required placeholder="Napisz tu swoje hasło"><br/>
            <input type="submit" value="send">
        </form>
    </div>
</body>
</html>