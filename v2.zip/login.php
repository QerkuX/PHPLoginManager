<?php
	// Checks if user and password are the same as in the database
    function login($conn){
        if (!isset($_POST["login"])) return -1; //There is no data given
		
        $login = $_POST["login"];
		
		// Selects element with login the user has put in
        $sql = "SELECT login, password FROM accounts WHERE login='$login'";
        $result = $conn->query($sql);

        if ($result->num_rows == 0) return -1; // There is no accounts with that login
		
		// Goes thru all valid elements (in this case only one)
        while($row = $result->fetch_assoc()){
            if ($row["password"] != $_POST["password"]) return -2; // Password is wrong

            return 0; // Login and password are valid
        }
    }

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "user_data";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
	
    // If login and password are valid, go to main page as a logged in user
    if (login($conn) == 0) header("location: index.php?user=1");
    else header("location: index.php?user=0&error=1");
?>