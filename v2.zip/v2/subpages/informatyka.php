<?php
    if (!isset($_GET["user"])){
        $user = 0;
        $name = "";
    }
    else{
        $user = $_GET["user"];
        $name = $_GET["name"];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>Strona główna</title>
</head>
<body>
    <div class="header center">
        <div class="header_left center"><h1>Moja strona</h1></div>

        <!-- Subpages -->
        <div class="header_middle center">
            <a href="gotowanie.php<?php echo "?user=" . $user . "&name=" . $name?>">Gotowanie</a>
            <a href="sport.php<?php echo "?user=" . $user . "&name=" . $name?>">Sport</a>
            <a href="informatyka.php<?php echo "?user=" . $user . "&name=" . $name?>">Informatyka</a>
            <!-- This option is only visible if user is logged in -->
            <?php
                if ($user){
                    echo "<a href='hackowanie.php" . "?user=" . $user . "&name=" . $name . "'>Konto</a>";
                }
            ?>
        </div>
        <div class="header_right center"><a href="../index.php<?php echo "?user=" .  $user . "&name=" . $name?>"><div class="login_button center">Strona Główna</div></a></div>
    </div>
    <div class="middle center" style="background-image: url(../images/informatyka.jpg);background-position: center;background-size: cover;"></div>
</body>
</html>