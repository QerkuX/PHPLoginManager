<?php
    if (!isset($_GET["user"])){
        $user = 0;
        $name = "";
    }
    else{
        $user = $_GET["user"];
        $name = $_GET["name"];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Strona główna</title>
</head>
<body style="background-image: url(images/bg.webp);background-position: center;background-size: cover;">
    <div class="header center">
        <div class="header_left center"><h1>Moja strona</h1></div>

        <!-- Subpages -->
        <div class="header_middle center">
            <a href="subpages/gotowanie.php<?php echo "?user=" . $user . "&name=" . $name?>">Gotowanie</a>
            <a href="subpages/sport.php<?php echo "?user=" . $user . "&name=" . $name?>">Sport</a>
            <a href="subpages/informatyka.php<?php echo "?user=" . $user . "&name=" . $name?>">Informatyka</a>
            <!-- This option is only visible if user is logged in -->
            <?php
                if ($user){
                    echo "<a href='subpages/hackowanie.php" . "?user=" . $user . "&name=" . $name . "'>Konto</a>";
                }
            ?>
        </div>
        <div class="header_right center"><a href="index.php<?php echo "?user=" .  $user . "&name=" . $name?>"><div class="login_button center">Strona Główna</div></a></div>
    </div>
    <div class="middle center">
        <!-- Logging form -->
        <?php
        if ($user == 0){
        ?>
        <form method="POST" action="login.php" class="center">
            <?php
                    if (isset($_GET["error"])){
                        $data = ["Konto z tą nazwą nie istnieje", "Podano niepoprawne hasło", "Konto z tą nazwą już istnieje"];
                        echo "<p>" . $data[$_GET["error"]-1] . "</p>";
                    }
            ?>
            LOGIN: <input type="text" name="login" required placeholder="Napisz tu swój login"><br/>
            PASSWORD: <input type="password" name="password" required placeholder="Napisz tu swoje hasło"><br/>
            <div class="buttons">
                <input type="submit" value="Login" name="login_button">
                <input type="submit" value="Register" name="register_button">
            </div>
        </form>
        <?php
        }
        else{
        ?>
        <form class="center">
            <div class="buttons">
            <button type="button" name="logout_button" onclick="logout()">Wyloguj</button>
            <button type="button" name="delete_account_button" onclick="delete_account()">Usuń konto</button>
            </div>
        </form>
        <?php
        }
        ?>
    </div>
    <script>
        function logout(){
            window.location.href = "index.php";
        }

        function delete_account(){
            window.location.href = "login.php<?php echo "?name=" . $name?>";
        }
    </script>
</body>
</html>