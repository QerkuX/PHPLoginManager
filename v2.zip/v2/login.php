<?php
    function validate_data($conn, $login, $password){
        $sql = "SELECT account_type, login, password from user_data WHERE login='$login'";
        $result = $conn->query($sql);

        if ($result->num_rows == 0){
            return 1;
        }

        while($row = $result->fetch_assoc()){
            if ($password != $row["password"]){
                return 2;
            }

            return 0;
        }
    }

    $conn = new mysqli("localhost", "root", "", "accounts");

    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    if (isset($_POST["login"])){
        $login = htmlspecialchars($_POST["login"]);
        $password = htmlspecialchars($_POST["password"]);

        $result = validate_data($conn, $login, $password);

        if (isset($_POST["login_button"])){
            if ($result == 0){
                header("Location: index.php?user=1&name=$login"); 
            } else{ // 1 - Account doesn't exist | 2 - Wrong password
                header("Location: index.php?error=" . strval($result));
            }
        }

        if (isset($_POST["register_button"])){
            if ($result != 1){
                header("Location: index.php?error=3");
            } else{
                $sql = "INSERT INTO user_data VALUES (null, 'user', '$login', '$password')";
                $result = $conn->query($sql);
                header("Location: index.php?user=1&name=$login"); 
            }
        }
    }

    if (isset($_GET["name"])){
        $name = $_GET["name"];
        echo $name;
        $sql = "DELETE FROM user_data WHERE login='$name'";
        $result = $conn->query($sql);
        header("Location: index.php"); 
    }   
?>